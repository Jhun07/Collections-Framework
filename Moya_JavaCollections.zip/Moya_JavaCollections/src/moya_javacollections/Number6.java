/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package moya_javacollections;

import java.util.ArrayList;
import java.util.Collections;

/**
 *
 * @author 2ndyrGroupA
 */
public class Number6 {
    public static void main(String[] args) {
        ArrayList<String> array = new ArrayList<String>();
        array.add("Rejoice");
        array.add("Clear");
        array.add("Sunsilk");
        array.add("Tresseme");
        array.add("Pantene");
        array.add("Granier");
             
        ArrayList<String> array2 = new ArrayList<String>();
        array2.add("Keratine");
        array2.add("Sunsilk");
        array2.add("Dove");
        array2.add("Pantene");
        
        System.out.println(array);
        System.out.println(array2);
        
        array2.retainAll(array);
        System.out.println("Common Values: " + array2);
        
    
}
}
