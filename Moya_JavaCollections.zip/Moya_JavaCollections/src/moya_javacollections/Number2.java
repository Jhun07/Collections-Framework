/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package moya_javacollections;

import java.util.ArrayList;
import java.util.Collections;

/**
 *
 * @author 2ndyrGroupA
 */
public class Number2 {
     public static void main(String[] args) {
        ArrayList<String> array = new ArrayList<String>();
        array.add("Rejoice");
        array.add("Clear");
        array.add("Sunsilk");
        array.add("Pantene");
        
        Collections.shuffle(array);
        System.out.println("Random Shampoo: " + array);
    
}
}