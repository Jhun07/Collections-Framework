/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package moya_javacollections;
import java.util.ArrayList;
import java.util.Collections;




/**
 *
 * @author 2ndyrGroupA
 */
public class Number1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        ArrayList<String> array = new ArrayList<String>();
        array.add("Rejoice");
        array.add("Clear");
        array.add("Sunsilk");
        array.add("Pantene");
        
        Collections.sort(array);
        System.out.println("Sorted Shampoo: " + array);
        
    }
    
}
