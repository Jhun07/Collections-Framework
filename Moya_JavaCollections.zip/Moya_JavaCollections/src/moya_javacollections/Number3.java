/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package moya_javacollections;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 *
 * @author 2ndyrGroupA
 */
public class Number3 {
     public static void main(String[] args) {

ArrayList<Integer> arr = new ArrayList<Integer>();
      arr.add(89);
      arr.add(9);
      arr.add(23);
      arr.add(24);
      arr.add(81);
      arr.add(7);
   
      int min = arr.get(0);
      for(int i = 1; i < arr.size(); i++) {
          if (arr.get(i) < min) {
              min = arr.get(i);
          }
      }
   
      System.out.println("Original Lists: " + arr);
     
      int position = arr.indexOf(min);
      arr.remove(position);
      arr.add(0, min );
   
      System.out.println("After lists:   " + arr);
     }
}