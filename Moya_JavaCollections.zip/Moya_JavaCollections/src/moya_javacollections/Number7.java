/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package moya_javacollections;

import java.util.ArrayList;
import java.util.Collections;

/**
 *
 * @author 2ndyrGroupA
 */
public class Number7 {

    public static void main(String[] args) {
        ArrayList<String> array = new ArrayList<String>();
        array.add("Rejoice");
        array.add("Clear");
        array.add("Tresseme");
        array.add("Pantene");
        array.add("Sunsilk");
        array.add("Dove");
        array.add("Granier");

        ArrayList<String> array2 = new ArrayList<String>();
        array2.add("Keratine");
        array2.add("Dove");
        array2.add("Sunsilk");
        array2.add("Pantene");
        array2.add("Granier");

        System.out.println("Random Shampoo: " + array);
        System.out.println("__________________________________________________________________________");
        System.out.println("Random Shampoo: " + array2);

        ArrayList<String> array3 = new ArrayList<String>();
        ArrayList<String> array4 = new ArrayList<String>();
 

        array3.addAll(array2);
        array3.removeAll(array);
        array4.addAll(array);
        array4.removeAll(array2);
        array4.addAll(array3);
        
        System.out.println("__________________________________________________________");
        System.out.println("Unique Values: " +array4);

    }
}
